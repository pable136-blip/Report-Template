import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const projects=sqliteTable('projects',{id:text('id').primaryKey(),data:text('data').notNull(),revision:integer('revision').notNull().default(1),updated:text('updated').notNull()});
export const settings=sqliteTable('settings',{key:text('key').primaryKey(),value:text('value').notNull()});
export const attachments=sqliteTable('attachments',{id:text('id').primaryKey(),projectId:text('project_id').notNull(),name:text('name').notNull(),size:integer('size').notNull(),uploaded:text('uploaded').notNull()});
